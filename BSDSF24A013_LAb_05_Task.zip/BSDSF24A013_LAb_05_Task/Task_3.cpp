#include <iostream>
using namespace std;
int countWays(int numStairs) 
{
    if (numStairs == 0)

        return 1;

    if (numStairs < 0)
        return 0;
    return 
    countWays(numStairs - 1) + countWays(numStairs - 2);
}

int main() 
{
    int n;
    cout << "enter num of stair: ";
    cin >> n;
    cout << "num of wayy to climb " << n << " stair: " << countWays(n) << endl;
}