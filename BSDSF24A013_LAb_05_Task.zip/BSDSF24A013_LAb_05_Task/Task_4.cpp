#include <iostream>
using namespace std;

int squareCounter(int k, int x, int y, int cx = 1024, int cy = 1024)
 {
    int left = cx - k;
    int right = cx + k;
    int top = cy - k;
    int bottom = cy + k;

    if (x < left || x > right || y < top || y > bottom)
        return 0;

    int count = 1;

    if (k > 1)
     {
        int newK = k / 2;
        count =count+squareCounter(newK, x, y, left, top);       
        count =count+ squareCounter(newK, x, y, right, top);      
        count = count+squareCounter(newK, x, y, left, bottom);   
        count = count+ squareCounter(newK, x, y, right, bottom);   
    }

    return count;
}

int main()
 {
    int k, x, y;
    cin >> k >> x >> y;

    cout << squareCounter(k, x, y) << endl;

    return 0;
}
