#include <iostream>
using namespace std;

int dec2oct(int n) 
{
    if (n < 8)
        return n;
    return
     dec2oct(n / 8) * 10 + (n % 8);
}

int main()
 {
    int n = 69;
    cout << "conversion of Number into octal to " << n << " is : " << dec2oct(n) << endl;
    n = 334;
    cout << "cconversion of Number into octal to" << n << " is : " << dec2oct(n) << endl;
    n = 3379;
    cout << "cconversion of Number into octal to" << n << " is : " << dec2oct(n) << endl;
    return 0;
}