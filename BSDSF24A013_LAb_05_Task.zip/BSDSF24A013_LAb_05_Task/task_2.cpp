#include <iostream>
#include <string>
using namespace std;

bool isprime(char d)
{
    return
     d == '2' || d == '3' || d == '5' || d == '7';
}

bool isGoodNumber(const string &s, int idx = 0) 
{
    if (idx >= s.length())
        return true;
    int dig = s[idx] - '0';
    if (idx % 2 == 0)
     {
        
        if (dig % 2 != 0)
            return false;
    } else 
    {
        if (!isprime(s[idx]))
            return false;
    }
    return
     isGoodNumber(s, idx + 1);
}

int main() 
{
    string ds[] = {"02468", "23478", "224365"};
    for (string d : ds)
    
    {
        bool good = isGoodNumber(d, 0);
        cout << "digit string: " << d << " is " << (good ? "good" : "not good") << endl;
    }
    return 0;
}